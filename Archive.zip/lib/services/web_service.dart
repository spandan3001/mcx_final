import 'package:html/parser.dart';
import 'package:html/dom.dart' as dom;
import 'package:mcx_live/models/bid_price_model.dart';

class WebService {
  static List<BidPriceModel> getBidPrices(String rawData) {
    List<BidPriceModel> bidPrices = [];
    dom.Document html = parse(rawData);
    List<dom.Element> elementSafe = html.querySelectorAll('tr.remove');
    for (dom.Element element in elementSafe) {
      List<dom.Element> bidElement = element.querySelectorAll("td");
      List<String> data = bidElement.map((e) => e.text).toList();

      bidPrices.add(BidPriceModel.fromSnapshot(data));
    }
    return bidPrices;
  }

  static List<String> getDates(String rawData) {
    dom.Document html = parse(rawData);
    List<dom.Element> elementSafe =
        html.querySelectorAll('#ddlExpiryDate > option');
    List<String> data = elementSafe.map((e) => e.text).toList();
    print(data);
    return data;
  }

  void completeData() {}

  static void getCommodityData(String rawData) {
    dom.Document html = parse(rawData);

    dom.Element? commodity = html.querySelector('#ProductHeading');
    print(commodity?.text);

    dom.Element? price = html.querySelector('span.q-price');
    print(price?.text);

    dom.Element? priceChange = html.querySelector('#litPriceChange');
    print(priceChange?.text);

    dom.Element? priceChangePer = html.querySelector('#litPriceChangePercent');
    print(priceChangePer?.text);

    dom.Element? todayMin = html.querySelector('span.today-min');
    print(todayMin?.text);

    dom.Element? todayMax = html.querySelector('span.today-max');
    print(todayMax?.text);

    // dom.Element? lifeTimeMin = html.querySelector('span.lifetime-min');
    // print(lifeTimeMin?.text);
    //
    // dom.Element? lifeTimeMax = html.querySelector('span.lifetime-max');
    // print(lifeTimeMax?.text);
  }
}
