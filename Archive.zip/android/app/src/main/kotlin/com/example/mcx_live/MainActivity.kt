package com.example.mcx_live;

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
