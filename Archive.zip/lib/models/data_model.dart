import 'bid_price_model.dart';

class DataModel {
  final String commodity;
  final String price;
  final String chg;
  final String chgPercent;
  final String? open;
  final String high;
  final String low;
  final String buyPrice;
  final String sellPrice;
  final String date;
  final BidPriceModel bidPriceModel;

  const DataModel({
    required this.commodity,
    required this.price,
    required this.chg,
    required this.chgPercent,
    this.open,
    required this.low,
    required this.high,
    required this.date,
    required this.buyPrice,
    required this.sellPrice,
    required this.bidPriceModel,
  });

  factory DataModel.fromSnapshot(List<dynamic> data) {
    return DataModel(
      commodity: data[0],
      price: data[1],
      chg: data[2],
      chgPercent: data[3],
      open: data[4],
      high: data[5],
      low: data[6],
      date: data[8],
      bidPriceModel: data[9],
      buyPrice: '',
      sellPrice: '',
    );
  }
}
