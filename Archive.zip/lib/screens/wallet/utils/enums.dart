enum Amount {
  a1500,
  a3000,
  a6000,
}

enum TypeOfSubmit { add, withdraw }
