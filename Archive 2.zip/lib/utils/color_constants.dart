import 'dart:ui';

const kGradient1 = Color(0xff12c1fc);
const kGradient2 = Color(0xff3669fb);
const kGradient3 = Color(0xff0409f8);
const kAmountColor = Color(0xff010478);
const kShadowColor = Color(0x5b000000);
const kBorderColor = Color(0xff979a9f);
const kWhite = Color(0xFFFFFFFF);
const kPrimaryYellowColor = Color(0xFFF5C249);
const kPrimaryBackgroundColor = Color(0xFF16171D);
const kSecondaryBackgroundColor = Color(0xFF383B45);
