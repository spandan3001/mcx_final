import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:mcx_live/services/web_service.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../utils/enums/mcx_code.dart';
import 'mcx_data_service.dart';

class MCX extends StatefulWidget {
  const MCX({super.key});

  @override
  State<MCX> createState() => _MCXState();
}

class _MCXState extends State<MCX> {
  @override
  void initState() {
    super.initState();
  }

  void getAllData(int i) {
    if (i == (McxCom.values.length) - 1) {
      Timer(const Duration(seconds: 30), () {
        Uri url = MCXServices.getUri(McxCom.values[i]);
        getRequest(url, McxCom.values[i]);
        getAllData(0);
      });
    } else {
      Timer(const Duration(seconds: 30), () {
        Uri url = MCXServices.getUri(McxCom.values[i]);
        getRequest(url, McxCom.values[i]);
        getAllData(i + 1);
      });
    }
  }

  Future<void> getRequest(Uri url, McxCom mcxCom) async {
    WebController.controllers[mcxCom.name] = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0x00000000))
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {},
          onPageStarted: (String url) {},
          onPageFinished: (String url) async {
            final html = await WebController.controllers[mcxCom.name]
                ?.runJavaScriptReturningResult(
                    'new XMLSerializer().serializeToString(document)');
            WebService.getCommodityData(json.decode(html.toString()));
            print("---------------------");
          },
          onWebResourceError: (WebResourceError error) {},
          onNavigationRequest: (NavigationRequest request) {
            if (request.url.startsWith('https://www.youtube.com/')) {
              return NavigationDecision.prevent;
            }
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(url);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: TextButton(
          onPressed: () async {
            getAllData(0);
          },
          child: const Text("press"),
        ),
      ),
    );
  }
}
