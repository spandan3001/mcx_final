class BidPriceModel {
  final String? bidVol;
  final String? bidPrice;
  final String? askPrice;
  final String? askVol;

  const BidPriceModel({
    this.bidVol,
    required this.bidPrice,
    required this.askPrice,
    required this.askVol,
  });

  factory BidPriceModel.fromSnapshot(List<dynamic> data) {
    if (data.length == 4) {
      return BidPriceModel(
        bidVol: data[0],
        bidPrice: data[1],
        askPrice: data[2],
        askVol: data[3],
      );
    } else {
      return BidPriceModel(
          bidPrice: data[0], askPrice: data[1], askVol: data[2]);
    }
  }
}
