import 'package:flutter/material.dart';

class MCXServices extends ChangeNotifier {
  void calculate() {}
}
