import 'package:mcx_live/utils/enums/mcx_code.dart';

class MCXServices {
  static const baseurl =
      "https://www.mcxindia.com/en/market-data/get-quote/FUTCOM";
  static Uri getUri(McxCom mcxCom) {
    return Uri.parse("$baseurl/${mcxCom.name}");
  }
}
